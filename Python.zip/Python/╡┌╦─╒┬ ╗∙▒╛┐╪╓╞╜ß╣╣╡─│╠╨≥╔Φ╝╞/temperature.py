celsius = int(input("请输入一个摄氏温度: "))
fahrenheit = (9 / 5) * celsius + 32
print('华氏温度: ')
print(fahrenheit);
