    ##numA = 3
##numB = 4
##if numA <= numB:
##    print("numB是比较大的数")

##while (True):
##    numA = int(input('输入一个整数: '))
##    numB = int(input('输入一个整数: '))
##    numC = int(input('输入一个整数: '))
##    if numA >= numB:
##        if numA >= numC:
##            print("numA最大");
##        else:
##            print("numC最大");
##    else:
##        if numB >= numC:
##            print("numB最大");
##        else:
##            print("numC最大");

##while (True):
##    numA = int(input('输入一个整数: '))
##    numB = int(input('输入一个整数: '))
##    numC = int(input('输入一个整数: '))
##    if numA >= numB and numA >= numC:
##        print("numA最大")
##    elif numB >= numA and numB >= numC:
##        print("numB最大")
##    elif numC >= numA and numC >= numA:
##        print("numC最大")

##name=["linaijun", "chengjiaojiao", "linchengxu"]
##name=["linaijun", "chengjiaojiao", "linchengxu"]

##for n in name:
##    print(n)

##mystr=input("请输入一个字符串:\n");
##patten_str="0123456789";
##founderr=False
##
##for c in mystr:
##    if c not in patten_str:
##        founderr=True
##if founderr:
##    print("包含非数字字符");
##else:
##    print("包含数字字符");

##numHeads = 35
##numLegs = 94
##
##for numChickens in range(0, numHeads+1):
##    numRabits = numHeads - numChickens
##    if 2 * numChickens + 4 * numRabits == numLegs:
##        print("numChickens:", numChickens)
##        print("numRabits:", numRabits)

##cunyuan = 10000
##years = 0
##while cunyuan < 20000:
##    years += 1
##    cunyuan = cunyuan * (1 + 0.019)
##print(str(years) + "年以后，存款会翻番")

##mylist = ["zope", "Python", "perl", "Linux"]
##for technic in mylist:
##    if technic == "perl":
##        pass
##    else:
##        print(technic)

##numbers = {100, 25, 125, 50, 150, 75, 175}
##
##for x in numbers:
##    print(x)
##    if x == 50:
##        print("找到了")
##        break
    
##for i in range(1,11):
##    s = ""
##    for j in range(1,i+1):        
##        s += "*"
##    print(s)

##for i in range(1,11):
##    s = ""
##    for j in range(1,11-i):
##        s += " "
##    for k in range(1,2*i):
##        s += "*"
##    print(s)


##for i in range(1, 11):
##    s = ""
##    if 11 -i > 5:
##        m = 11 - i
##        n = 2 * i
##    else:
##        m = i 
##        n = 22 - 2 * i
##    for h in range(1, m):
##        s += " "
##    for k in range(1, n):
##        s += "*"
##    print(s)


##mylist = range(1,31)
##delete_list = []
##x = 0
##i = 0
##while len(delete_list) < 15:
##    if x > 29:
##        x = 0
##    if mylist[x] not in delete_list:
##        i += 1
##    if i == 9:
##        print(mylist[x])
##        print("出列:")
##        delete_list.append(mylist[x])
##        i = 0
##    x = x + 1


##mylist = range(1,40)
##delete_list = []
##x = 0
##i = 0
##while len(delete_list) < 40:
##    if x > 38:
##        x = 0
##    if mylist[x] not in delete_list:
##        i += 1
##    if i == 3:
##        print(mylist[x])
##        print("出列:")
##        delete_list.append(mylist[x])
##        i = 0
##    x = x + 1

##mystr="篮球、足球、乒乓球、羽毛球、电子游戏、看书、旅游、电影、音乐"
##li = mystr.split('、')
##print("该生的爱好有"+str(len(li))+"项")

##mystr="0122202341020303"
##print(mystr+"\n")
##li=list(mystr)
##for i in range(1,len(li), 2):
##    li[i] = '-'
##mystr="".join(li)
##print(mystr)

##while True:
##    str = input("请输入一个字符串(quit 退出)\n")
##    if  str == "quit":
##        break
##    else:
##        if str.count('梦') != 0:
##            print('找到字符梦')
##        else:
##            print('未找到字符梦')


##for x in range(1,13):
##    for y in range(1,13):
##        if x + y == 12 and 2 * x - 3 * y == 14:
##            print("x = ",x, " y = ", y)

##while True:
##    idstr = input("请输入您的身份证号:")
##    year = int(idstr[6:10])
##    month = int(idstr[10:12])
##    day = int(idstr[12:14])
##    if int(idstr[16]) % 2 == 1:
##        sex = '男'
##    else:
##        sex = '女'
##    print('您的出生日期为',str(year),'年',str(month),'月',str(day),'日','性别为',sex)

##count = 1
##numList = []
##countNum = 0
##while True:    
##    if countNum >= 10:
##        numList.sort()
##        print(numList)
##        break
##
##    inputStr = "请输入第", count, "个数字"
##    numStr = input(inputStr)
##
##    if not (numStr.isdigit()):
##        print("必须输入数字")
##        continue
##
##    elif int(numStr) in numList:
##        print("数字有重复")
##        continue
##    else:
##        numList.append(int(numStr))
##        count += 1
##        countNum += 1
        
##n  = int(input('n = '))
##sum = 0
##for i in range(1, n + 1):
##    x = int(input())
##    sum += x
##print(sum)

##mysum = 0
##while True:
##    x =  int(input("Please input a number: "))
##    if x == -1:
##        break
##    mysum += x
##print(mysum)

##a = []
##while True:
##    x = int(input("Please input a number: "))
##    if  x == -1:
##        breakmd

##    a.append(x);
##s = sum(a)
##n = len(a)
##print('n =', n)
##print('s =', s)
##print('Average =', s/n)

a = input()
b = input()
c = input()
print(a, b, c, a + b + c)
