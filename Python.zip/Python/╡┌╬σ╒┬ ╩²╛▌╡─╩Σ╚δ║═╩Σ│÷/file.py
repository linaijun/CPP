def main():
    a = 10
    b = 10
    c = 10
    d = 10
    e = 10
    
main()
