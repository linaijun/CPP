#----------------------------------------------
#This is my second Program
#----------------------------------------------

##a = input("请输入一个数字:\n");
##print (a);
##print(a+a);
##
##print ("林爱军")

while (1):
    year = int(input("Please input year: "));
    print(year % 4 == 0 and year % 100 != 0 or year % 400 == 0)
