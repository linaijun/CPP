#f = open("data.txt", "r")
#a = f.read()
#print(a)
#L1 = a.split()
#print(L1)

#def pr():
#    print("*******")
#    print("*******")
#pr()
#print("Welcome")
#pr()

#def rt(a):
#    for n in range(a):
#        for m in range(n+1):
#            print('*', end = '')
#        print()

#while True:
#    b = input("input Line:")
#    if b == '0':
#        break
#    c = int(b)
#    rt(c)

#def fact(n):
#    result = 1
#    for i in range(1,n+1):
#        result *= i
#    return result

#while True:
#    n = int(input("Input a number: "))
#    if (n == -1):
#        break
#    result = fact(n)
#    print(result)
#def f1():
#    x = 5
#    y = 6 
#    f2(x)
#    print(x+y)
#def f2(z):
#    y = 1
#    print(z+y)
#f1()



